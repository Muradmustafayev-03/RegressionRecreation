# RegressionRecreation
Recreation of different kinds of regression using optimisation algorithms
